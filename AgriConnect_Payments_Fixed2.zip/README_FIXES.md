AgriConnect Payments Fixed

Fixes:
- Added missing loadAlerts() function.
- Added missing updatePaymentField() function.
- UPI and Google Pay now ask for a UPI ID, not 4 card digits.
- Checkout sends method=upi/gpay and upiId correctly.
- Card continues to require exactly 4 digits.

Run:
1. PowerShell: .\RUN_AGRICONNECT.bat
2. Open http://localhost:8090
