@echo off
setlocal EnableExtensions

title AgriConnect - Build and Run

cd /d "%~dp0"

echo.
echo ==========================================
echo        AgriConnect Web Application
echo ==========================================
echo.

REM Check Java compiler
where javac >nul 2>nul
if errorlevel 1 (
    echo [ERROR] javac was not found in PATH.
    echo.
    echo Please install/configure JDK and make sure:
    echo     javac -version
    echo works in Command Prompt.
    echo.
    pause
    exit /b 1
)

echo [1/4] Checking Java version...
java -version
echo.

if not exist "src\main\java" (
    echo [ERROR] src\main\java was not found.
    echo Please run this file from the AgriConnect_Web_Complete folder.
    echo.
    pause
    exit /b 1
)

echo [2/4] Preparing build folder...
if exist "out" rmdir /s /q "out"
mkdir "out"

if exist "sources.txt" del /q "sources.txt"

echo [3/4] Finding and compiling Java source files...
REM Generate a plain Windows absolute-path list for javac.
dir /s /b "src\main\java\*.java" > "sources.txt"

if not exist "sources.txt" (
    echo [ERROR] No Java source files were found.
    pause
    exit /b 1
)

for %%A in ("sources.txt") do if %%~zA==0 (
    echo [ERROR] The Java source list is empty.
    pause
    exit /b 1
)

javac -encoding UTF-8 -d "out" @"sources.txt"

if errorlevel 1 (
    echo.
    echo ==========================================
    echo [BUILD FAILED]
    echo ==========================================
    echo.
    echo Read the compiler errors above.
    echo No server was started.
    echo.
    pause
    exit /b 1
)

echo.
echo [SUCCESS] Java compilation completed.
echo.

if not exist "out\com\agriconnect\web\AgriConnectServer.class" (
    echo [ERROR] AgriConnectServer.class was not created.
    echo The web server class is missing from the project.
    echo.
    pause
    exit /b 1
)

echo [4/4] Starting AgriConnect Web Server...
echo.
echo ==========================================
echo   Website: http://localhost:8090
echo ==========================================
echo.
echo Keep this window open while using AgriConnect.
echo Press CTRL+C to stop the server.
echo.

java -cp "out" com.agriconnect.web.AgriConnectServer 8090

echo.
echo AgriConnect server stopped.
pause
