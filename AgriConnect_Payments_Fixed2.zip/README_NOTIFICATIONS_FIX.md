AgriConnect Payments Fixed2

Fixed missing loadNotifications() function. Notifications now load from /api/notifications and render safely in the notification drawer.

Run .\RUN_AGRICONNECT.bat and open http://localhost:8090.
