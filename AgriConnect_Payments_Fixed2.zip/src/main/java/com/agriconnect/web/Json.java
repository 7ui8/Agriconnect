package com.agriconnect.web;

import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class Json {
    private Json(){}

    static Map<String,String> body(HttpExchange e) throws IOException {
        String s=new String(e.getRequestBody().readAllBytes(),StandardCharsets.UTF_8).trim();
        Map<String,String> out=new LinkedHashMap<>();
        if(s.isEmpty()||s.equals("{}")) return out;
        if(s.startsWith("{")&&s.endsWith("}")) s=s.substring(1,s.length()-1);
        for(String part:split(s,',')){
            List<String> kv=split(part,':');
            if(kv.size()<2) continue;
            String k=unquote(kv.get(0).trim());
            String v=kv.get(1).trim();
            for(int i=2;i<kv.size();i++) v+=":"+kv.get(i);
            out.put(k,unquote(v));
        }
        return out;
    }

    private static List<String> split(String s,char sep){
        List<String> r=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false,esc=false;
        for(char c:s.toCharArray()){
            if(esc){b.append(c);esc=false;continue;}
            if(c=='\\'&&q){b.append(c);esc=true;continue;}
            if(c=='"'){q=!q;b.append(c);continue;}
            if(c==sep&&!q){r.add(b.toString());b.setLength(0);}else b.append(c);
        }
        r.add(b.toString());return r;
    }

    private static String unquote(String s){
        s=s.trim();
        if(s.length()>=2&&s.charAt(0)=='"'&&s.charAt(s.length()-1)=='"') s=s.substring(1,s.length()-1);
        return s.replace("\\\"","\"").replace("\\\\","\\").replace("\\n","\n").replace("\\r","\r");
    }

    static String stringify(Object o){
        if(o==null)return "null";
        if(o instanceof String || o instanceof Character || o instanceof Enum<?>) return quote(String.valueOf(o));
        if(o instanceof Number || o instanceof Boolean) return String.valueOf(o);
        if(o instanceof Map<?,?> m){
            return m.entrySet().stream().map(e->quote(String.valueOf(e.getKey()))+":"+stringify(e.getValue()))
                    .collect(java.util.stream.Collectors.joining(",","{","}"));
        }
        if(o instanceof Iterable<?> it){
            StringBuilder b=new StringBuilder("[");boolean first=true;
            for(Object x:it){if(!first)b.append(',');first=false;b.append(stringify(x));}
            return b.append(']').toString();
        }
        return quote(String.valueOf(o));
    }
    static String quote(String s){
        StringBuilder b=new StringBuilder("\"");
        for(char c:s.toCharArray()){
            switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:b.append(c);}
        }
        return b.append('"').toString();
    }
}
