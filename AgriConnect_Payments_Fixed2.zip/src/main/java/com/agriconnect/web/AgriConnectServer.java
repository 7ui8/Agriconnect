package com.agriconnect.web;

import com.agriconnect.model.*;
import com.agriconnect.service.*;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class AgriConnectServer {
    private static final int DEFAULT_PORT = 8080;
    private final UserService users = new UserService();
    private final MarketplaceService market = new MarketplaceService();
    private final OrderService orders = new OrderService();
    private final WeatherService weather = new WeatherService();
    private final CropAdvisoryService advisories = new CropAdvisoryService();
    private final ReportService reports = new ReportService();
    private final Map<String, User> sessions = new ConcurrentHashMap<>();
    private final Path publicDir;

    public AgriConnectServer() {
        publicDir = Paths.get("src", "main", "resources", "public").toAbsolutePath().normalize();
        seed();
    }

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : DEFAULT_PORT;
        new AgriConnectServer().start(port);
    }

    private void start(int port) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", this::handle);
        server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        server.start();
        System.out.println("AgriConnect web app: http://localhost:" + port);
        System.out.println("Demo: john@farm.com / pass123 | mary@shop.com / pass123 | alice@buy.com / pass123 | admin@agriconnect.com / admin123");
    }

    private void handle(HttpExchange ex) throws IOException {
        try {
            addCors(ex.getResponseHeaders());
            if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) { send(ex, 204, ""); return; }

            String path = ex.getRequestURI().getPath();
            if (path.startsWith("/api/")) {
                handleApi(ex, path);
            } else {
                serveStatic(ex, path);
            }
        } catch (Exception e) {
            e.printStackTrace();
            json(ex, 500, Map.of("error", e.getMessage() == null ? "Server error" : e.getMessage()));
        } finally {
            ex.close();
        }
    }

    private void handleApi(HttpExchange ex, String path) throws IOException {
        String method = ex.getRequestMethod();
        User me = currentUser(ex);

        if (path.equals("/api/health") && method.equals("GET")) { json(ex, 200, Map.of("ok", true, "app", "AgriConnect")); return; }

        if (path.equals("/api/auth/register") && method.equals("POST")) {
            Map<String,String> b = Json.body(ex);
            String name=need(b,"name"), email=need(b,"email"), password=need(b,"password");
            String role=b.getOrDefault("role","BUYER").toUpperCase(Locale.ROOT);
            if (users.getAllUsers().stream().anyMatch(u -> u.getEmail().equalsIgnoreCase(email)))
                throw new IllegalArgumentException("An account with this email already exists.");
            User u = switch(role) {
                case "FARMER" -> users.registerFarmer(name,email,password);
                case "SELLER" -> users.registerSeller(name,email,password);
                default -> users.registerBuyer(name,email,password);
            };
            u.login(password);
            String token = UUID.randomUUID().toString();
            sessions.put(token,u);
            cookie(ex,token);
            json(ex,201,user(u));
            return;
        }

        if (path.equals("/api/auth/login") && method.equals("POST")) {
            Map<String,String> b=Json.body(ex);
            User u=users.login(need(b,"email"),need(b,"password")).orElseThrow(() -> new IllegalArgumentException("Invalid email or password."));
            String token=UUID.randomUUID().toString();
            sessions.put(token,u); cookie(ex,token); json(ex,200,user(u)); return;
        }

        if (path.equals("/api/auth/logout") && method.equals("POST")) {
            if(me!=null) me.logout();
            String token=cookieToken(ex); if(token!=null) sessions.remove(token);
            json(ex,200,Map.of("ok",true)); return;
        }

        if (path.equals("/api/me") && method.equals("GET")) { require(me); json(ex,200,user(me)); return; }

        if (path.equals("/api/products") && method.equals("GET")) {
            String q=query(ex,"q"), cat=query(ex,"category");
            List<Product> ps = q!=null ? market.searchByName(q) : cat!=null ? market.filterByCategory(cat) : market.getAllActive();
            json(ex,200,ps.stream().map(this::product).toList()); return;
        }

        if (path.equals("/api/products") && method.equals("POST")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers can add products.");
            Map<String,String>b=Json.body(ex);
            double price=Double.parseDouble(need(b,"price"));
            int quantity=Integer.parseInt(need(b,"quantity"));
            if(price < 0 || quantity < 1) throw new IllegalArgumentException("Enter a valid price and quantity.");
            String unit=b.getOrDefault("unit","kg");
            String farmName=b.getOrDefault("farmName",me.getName()+"'s Farm");
            String location=b.getOrDefault("location","");
            String description=b.getOrDefault("description","");
            String harvestDate=b.getOrDefault("harvestDate","");
            String photoUrl=b.getOrDefault("photoUrl","");
            Product p=market.addListing(me,need(b,"name"),need(b,"category"),price,quantity,
                    unit,farmName,location,description,harvestDate,photoUrl);
            json(ex,201,product(p)); return;
        }

        if (path.equals("/api/my-listings") && method.equals("GET")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers have listings.");
            if (me instanceof Farmer f) json(ex,200,f.getListings().stream().map(this::product).toList());
            else json(ex,200,((Seller)me).getListings().stream().map(this::product).toList());
            return;
        }

        if (path.matches("/api/products/\\d+$") && method.equals("PUT")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers can edit products.");
            int id=lastProductId(path);
            Product p=findProduct(id);
            if(p.getSeller()!=me) throw new IllegalArgumentException("You can only edit your own products.");
            Map<String,String>b=Json.body(ex);
            if(b.containsKey("price") && !b.get("price").isBlank()) p.setPrice(Double.parseDouble(b.get("price")));
            if(b.containsKey("quantity") && !b.get("quantity").isBlank()) p.setQuantity(Integer.parseInt(b.get("quantity")));
            if(b.containsKey("unit")) p.setUnit(b.get("unit"));
            if(b.containsKey("farmName")) p.setFarmName(b.get("farmName"));
            if(b.containsKey("location")) p.setLocation(b.get("location"));
            if(b.containsKey("description")) p.setDescription(b.get("description"));
            if(b.containsKey("harvestDate")) p.setHarvestDate(b.get("harvestDate"));
            if(b.containsKey("photoUrl")) p.setPhotoUrl(b.get("photoUrl"));
            json(ex,200,product(p)); return;
        }

        if (path.matches("/api/products/\\d+$") && method.equals("DELETE")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers can remove products.");
            int id=lastProductId(path);
            Product p=findProduct(id);
            if(p.getSeller()!=me) throw new IllegalArgumentException("You can only remove your own products.");
            p.deactivate(); json(ex,200,product(p)); return;
        }

        if (path.equals("/api/orders") && method.equals("GET")) {
            require(me);
            List<Order> os = me instanceof Buyer ? ((Buyer)me).getOrders() :
                    orders.getAllOrders();
            json(ex,200,os.stream().map(this::order).toList()); return;
        }

        if (path.equals("/api/orders") && method.equals("POST")) {
            requireRole(me,Role.BUYER);
            Map<String,String>b=Json.body(ex);
            int pid=Integer.parseInt(need(b,"productId")), qty=Integer.parseInt(need(b,"quantity"));
            Product p=market.getCatalog().stream().filter(x->x.getId()==pid).findFirst().orElseThrow(()->new IllegalArgumentException("Product not found."));
            if(qty<1) throw new IllegalArgumentException("Quantity must be at least 1.");
            Order o=orders.placeOrder((Buyer)me,List.of(new OrderItem(p,qty)));
            json(ex,201,order(o)); return;
        }

        if (path.matches("/api/orders/\\d+/pay") && method.equals("POST")) {
            requireRole(me,Role.BUYER);
            int id=lastId(path);
            Order o=findOrder(id);
            if(o.getBuyer()!=me) throw new IllegalArgumentException("You cannot pay for this order.");
            Map<String,String>b=Json.body(ex);
            String methodName=b.getOrDefault("method","card").toLowerCase(Locale.ROOT);
            Payment payment;
            switch(methodName){
                case "card" -> payment = new CardPayment(o,o.total(),need(b,"last4"));
                case "upi" -> payment = new UpiPayment(o,o.total(),need(b,"upiId"));
                case "gpay", "googlepay", "google_pay" -> payment = new GooglePayPayment(o,o.total(),need(b,"upiId"));
                default -> throw new IllegalArgumentException("Choose Card, UPI or Google Pay.");
            }
            boolean ok=orders.pay(o,payment);
            json(ex,200,Map.of("success",ok,"order",order(o))); return;
        }

        if (path.matches("/api/orders/\\d+/refund") && method.equals("POST")) {
            requireRole(me,Role.BUYER);
            Order o=findOrder(lastId(path));
            if(o.getBuyer()!=me) throw new IllegalArgumentException("You cannot refund this order.");
            orders.refund(o); json(ex,200,order(o)); return;
        }

        if (path.equals("/api/sales") && method.equals("GET")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers can view sales.");
            List<Order> sales = orders.getAllOrders().stream()
                    .filter(o -> o.getItems().stream().anyMatch(i -> i.getProduct().getSeller() == me))
                    .toList();
            json(ex,200,sales.stream().map(o -> saleOrder(o, me)).toList());
            return;
        }

        if (path.matches("/api/sales/\\d+/status") && method.equals("PUT")) {
            if (me == null || (me.getRole() != Role.SELLER && me.getRole() != Role.FARMER))
                throw new IllegalArgumentException("Only farmers and sellers can update sales.");
            Order o=findOrder(lastIdStatus(path));
            boolean ownsSale=o.getItems().stream().anyMatch(i -> i.getProduct().getSeller() == me);
            if(!ownsSale) throw new IllegalArgumentException("You can only update your own sales.");
            Map<String,String>b=Json.body(ex);
            Order.Status next=Order.Status.valueOf(need(b,"status").toUpperCase(Locale.ROOT));
            if(next != Order.Status.PAID && next != Order.Status.SHIPPED &&
               next != Order.Status.OUT_FOR_DELIVERY && next != Order.Status.DELIVERED)
                throw new IllegalArgumentException("Sales can be moved to PAID, SHIPPED, OUT_FOR_DELIVERY or DELIVERED.");
            o.setStatus(next);
            json(ex,200,saleOrder(o,me));
            return;
        }

        if (path.equals("/api/advisories") && method.equals("GET")) {
            requireRole(me,Role.FARMER);
            json(ex,200,((Farmer)me).getAdvisories().stream().map(this::advisory).toList()); return;
        }

        if (path.equals("/api/advisories") && method.equals("POST")) {
            requireRole(me,Role.FARMER);
            Map<String,String>b=Json.body(ex);
            CropAdvisory a=advisories.generateAdvisory((Farmer)me,need(b,"crop"),need(b,"soil"));
            json(ex,201,advisory(a)); return;
        }

        if (path.equals("/api/alerts") && method.equals("GET")) {
            json(ex,200,weather.getAlerts().stream().map(this::alert).toList()); return;
        }

        if (path.equals("/api/alerts") && method.equals("POST")) {
            requireRole(me,Role.ADMIN);
            Map<String,String>b=Json.body(ex);
            WeatherAlert.Severity s=WeatherAlert.Severity.valueOf(b.getOrDefault("severity","INFO").toUpperCase(Locale.ROOT));
            WeatherAlert a=weather.issueAlert(need(b,"region"),need(b,"description"),s);
            List<Farmer> fs=users.getAllUsers().stream().filter(Farmer.class::isInstance).map(Farmer.class::cast).toList();
            weather.broadcastToFarmers(a,fs);
            json(ex,201,alert(a)); return;
        }

        if (path.equals("/api/notifications") && method.equals("GET")) {
            require(me); json(ex,200,me.getInbox()); return;
        }

        if (path.equals("/api/dashboard") && method.equals("GET")) {
            require(me); json(ex,200,dashboard(me)); return;
        }

        if (path.equals("/api/admin/users") && method.equals("GET")) {
            requireRole(me,Role.ADMIN);
            json(ex,200,users.getAllUsers().stream().map(this::user).toList()); return;
        }

        if (path.equals("/api/admin/reports") && method.equals("GET")) {
            requireRole(me,Role.ADMIN);
            Report sales=reports.salesReport(orders.getAllOrders()), ur=reports.userReport(users);
            List<Seller> ss=users.getAllUsers().stream().filter(Seller.class::isInstance).map(Seller.class::cast).toList();
            Report top=reports.topSellersReport(ss);
            json(ex,200,Map.of("sales",report(sales),"users",report(ur),"topSellers",report(top))); return;
        }

        json(ex,404,Map.of("error","API route not found"));
    }

    private Map<String,Object> dashboard(User u) {
        Map<String,Object> m=new LinkedHashMap<>();
        m.put("summary",u.dashboardSummary()); m.put("role",u.getRole().name());
        m.put("productCount",market.getAllActive().size());
        if(u instanceof Farmer f) {
            m.put("advisoryCount",f.getAdvisories().size());
            m.put("listingCount",f.getListings().size());
            m.put("revenue",f.getTotalRevenue());
            m.put("salesCount",orders.getAllOrders().stream().filter(o -> o.getItems().stream().anyMatch(i -> i.getProduct().getSeller() == f)).count());
        }
        if(u instanceof Seller s) {
            m.put("listingCount",s.getListings().size());
            m.put("revenue",s.getTotalRevenue());
            m.put("salesCount",orders.getAllOrders().stream().filter(o -> o.getItems().stream().anyMatch(i -> i.getProduct().getSeller() == s)).count());
        }
        if(u instanceof Buyer b) { m.put("orderCount",b.getOrders().size()); m.put("spent",b.getOrders().stream().mapToDouble(Order::total).sum()); }
        if(u instanceof Admin) { m.put("users",users.getAllUsers().size()); m.put("orders",orders.getAllOrders().size()); }
        return m;
    }

    private Map<String,Object> user(User u){ return map("id",u.getId(),"name",u.getName(),"email",u.getEmail(),"role",u.getRole().name()); }
    private Map<String,Object> product(Product p){
        return map("id",p.getId(),"name",p.getName(),"category",p.getCategory(),
                "price",p.getPrice(),"quantity",p.getQuantity(),"active",p.isActive(),
                "seller",p.getSeller().getName(),"sellerRole",p.getSeller().getRole().name(),
                "unit",p.getUnit(),"farmName",p.getFarmName(),"location",p.getLocation(),
                "description",p.getDescription(),"harvestDate",p.getHarvestDate(),"photoUrl",p.getPhotoUrl());
    }
    private Map<String,Object> order(Order o){
        String paymentMethod = o.getPayment() == null ? null : (o.getPayment() instanceof CardPayment ? "CARD" : o.getPayment() instanceof GooglePayPayment ? "GOOGLE_PAY" : o.getPayment() instanceof UpiPayment ? "UPI" : "OTHER");
        return map("id",o.getId(),"status",o.getStatus().name(),"total",o.total(),"paymentMethod",paymentMethod,
                "createdAt",o.getCreatedAt().toString(),"statusUpdatedAt",o.getStatusUpdatedAt().toString(),
                "trackingId",trackingId(o.getId()),"estimatedDelivery",o.getCreatedAt().plusDays(5).toLocalDate().toString(),
                "items",o.getItems().stream().map(i->map("productId",i.getProduct().getId(),"name",i.getProduct().getName(),
                        "quantity",i.getQuantity(),"unitPrice",i.getProduct().getPrice(),"unit",i.getProduct().getUnit(),"subtotal",i.subtotal())).toList());
    }
    private String oCreated(Order o){ return o.toString().isEmpty() ? "" : "recent"; }
    private Map<String,Object> advisory(CropAdvisory a){ return map("crop",a.getCropName(),"recommendation",a.getRecommendation()); }
    private Map<String,Object> alert(WeatherAlert a){ return map("region",a.getRegion(),"severity",a.getSeverity().name(),"description",a.getDescription()); }
    private Map<String,Object> report(Report r){ return map("title",r.getTitle(),"content",r.getContent()); }

    private Map<String,Object> saleOrder(Order o, User owner){
        List<Map<String,Object>> items=o.getItems().stream()
                .filter(i -> i.getProduct().getSeller() == owner)
                .map(i -> map("productId",i.getProduct().getId(),"name",i.getProduct().getName(),
                        "quantity",i.getQuantity(),"unit",i.getProduct().getUnit(),
                        "unitPrice",i.getProduct().getPrice(),"subtotal",i.subtotal()))
                .toList();
        return map("id",o.getId(),"buyer",o.getBuyer().getName(),"status",o.getStatus().name(),
                "total",items.stream().mapToDouble(x -> ((Number)x.get("subtotal")).doubleValue()).sum(),
                "createdAt",o.getCreatedAt().toString(),"statusUpdatedAt",o.getStatusUpdatedAt().toString(),
                "trackingId",trackingId(o.getId()),"estimatedDelivery",o.getCreatedAt().plusDays(5).toLocalDate().toString(),
                "items",items);
    }

    private Product findProduct(int id){ return market.getCatalog().stream().filter(p->p.getId()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Product not found.")); }
    private static String trackingId(int id){ return "AGRI-" + String.format("%06d", id); }
    private static int lastProductId(String p){ return Integer.parseInt(p.replaceAll(".*/(\\d+)$","$1")); }
    private Order findOrder(int id){ return orders.getAllOrders().stream().filter(o->o.getId()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Order not found.")); }
    private static int lastId(String p){ return Integer.parseInt(p.replaceAll(".*/(\\d+)/(?:pay|refund)$","$1")); }
    private static int lastIdStatus(String p){ return Integer.parseInt(p.replaceAll(".*/(\\d+)/status$","$1")); }
    private static void require(User u){if(u==null)throw new IllegalArgumentException("Please log in first.");}
    private static void requireRole(User u,Role r){require(u);if(u.getRole()!=r)throw new IllegalArgumentException("This action requires the "+r+" role.");}
    private static String need(Map<String,String>b,String k){String v=b.get(k);if(v==null||v.isBlank())throw new IllegalArgumentException(k+" is required.");return v;}
    private static String query(HttpExchange e,String key){String q=e.getRequestURI().getRawQuery();if(q==null)return null;for(String p:q.split("&")){String[]a=p.split("=",2);if(a.length==2&&URLDecoder.decode(a[0],StandardCharsets.UTF_8).equals(key))return URLDecoder.decode(a[1],StandardCharsets.UTF_8);}return null;}
    private static void cookie(HttpExchange e,String token){e.getResponseHeaders().add("Set-Cookie","AGRICONNECT_SESSION="+token+"; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800");}
    private String cookieToken(HttpExchange e){String c=e.getRequestHeaders().getFirst("Cookie");if(c==null)return null;for(String p:c.split(";")){String[]a=p.trim().split("=",2);if(a.length==2&&a[0].equals("AGRICONNECT_SESSION"))return a[1];}return null;}
    private User currentUser(HttpExchange e){String t=cookieToken(e);return t==null?null:sessions.get(t);}
    private static void addCors(Headers h){h.set("Access-Control-Allow-Origin","http://localhost:8080");h.set("Access-Control-Allow-Credentials","true");h.set("Access-Control-Allow-Headers","Content-Type");h.set("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS");}
    private static void json(HttpExchange e,int status,Object obj)throws IOException{byte[]b=Json.stringify(obj).getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");e.sendResponseHeaders(status,b.length);e.getResponseBody().write(b);}
    private static void send(HttpExchange e,int status,String body)throws IOException{byte[]b=body.getBytes(StandardCharsets.UTF_8);e.sendResponseHeaders(status,b.length);e.getResponseBody().write(b);}

    private void serveStatic(HttpExchange e,String raw)throws IOException{
        String path=raw.equals("/")?"/index.html":raw;
        Path f=publicDir.resolve(path.substring(1)).normalize();
        if(!f.startsWith(publicDir)||!Files.exists(f)||Files.isDirectory(f)){send(e,404,"Not found");return;}
        String type=Files.probeContentType(f); if(type==null)type="application/octet-stream";
        byte[]b=Files.readAllBytes(f);e.getResponseHeaders().set("Content-Type",type);e.sendResponseHeaders(200,b.length);e.getResponseBody().write(b);
    }

    private void seed(){
        Farmer john=users.registerFarmer("John Otieno","john@farm.com","pass123");
        Seller mary=users.registerSeller("Mary AgriSupplies","mary@shop.com","pass123");
        users.registerBuyer("Alice Buyer","alice@buy.com","pass123");
        users.registerAdmin("Admin","admin@agriconnect.com","admin123");
        market.addListing(mary,"Hybrid Maize Seeds","Seeds",12.50,100);
        market.addListing(mary,"NPK Fertilizer 50kg","Fertilizer",35.00,40);
        market.addListing(mary,"Organic Tomato Seeds","Seeds",8.50,75);
        market.addListing(mary,"Neem Bio-Pesticide","Crop Protection",22.00,30);
        market.addListing(john,"Fresh Kerala Tomatoes","Fresh Produce",80.00,50,"kg",
                "John's Green Valley Farm","Palakkad, Kerala",
                "Freshly harvested tomatoes grown without synthetic pesticides.","2026-10-05",
                "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=900&q=80");
        advisories.generateAdvisory(john,"Maize","loamy");
        weather.issueAlert("Kerala","Heavy rain possible in the next 24 hours. Protect harvested crops and check drainage.",WeatherAlert.Severity.WARNING);
    }

    private static Map<String,Object> map(Object... a){Map<String,Object>m=new LinkedHashMap<>();for(int i=0;i<a.length;i+=2)m.put(String.valueOf(a[i]),a[i+1]);return m;}
}
