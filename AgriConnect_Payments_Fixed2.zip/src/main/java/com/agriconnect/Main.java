package com.agriconnect;

import com.agriconnect.common.NotificationService;
import com.agriconnect.model.*;
import com.agriconnect.service.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Console entry point. Acts as the "Front End (Client Layer)" talking to the
 * "Application Layer (Backend)" services, wiring together all six modules
 * from the AgriConnect architecture diagram.
 */
public class Main {

    private static final Scanner sc = new Scanner(System.in);

    private static final UserService userService = new UserService();
    private static final CropAdvisoryService advisoryService = new CropAdvisoryService();
    private static final MarketplaceService marketService = new MarketplaceService();
    private static final WeatherService weatherService = new WeatherService();
    private static final OrderService orderService = new OrderService();
    private static final ReportService reportService = new ReportService();
    private static final NotificationService notifier = NotificationService.getInstance();

    private static User currentUser;

    public static void main(String[] args) {
        seedDemoData();
        System.out.println("=================================================");
        System.out.println("   Welcome to AgriConnect - Console Edition");
        System.out.println("   Cultivating Connections. Empowering Farmers.");
        System.out.println("=================================================");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                running = authMenu();
            } else {
                mainMenu();
            }
        }
        System.out.println("Goodbye!");
    }

    // ---------------------------------------------------------------- AUTH

    private static boolean authMenu() {
        System.out.println("\n1. Login  2. Register  3. Exit");
        switch (readInt("Choose: ")) {
            case 1 -> doLogin();
            case 2 -> doRegister();
            case 3 -> { return false; }
            default -> System.out.println("Invalid choice.");
        }
        return true;
    }

    private static void doLogin() {
        String email = readLine("Email: ");
        String password = readLine("Password: ");
        userService.login(email, password).ifPresentOrElse(
                u -> {
                    currentUser = u;
                    System.out.println("Welcome back, " + u.getName() + "!");
                },
                () -> System.out.println("Invalid credentials."));
    }

    private static void doRegister() {
        String name = readLine("Name: ");
        String email = readLine("Email: ");
        String password = readLine("Password: ");
        System.out.println("Role: 1. Farmer  2. Seller  3. Buyer  4. Admin");
        int r = readInt("Choose: ");
        User u = switch (r) {
            case 1 -> userService.registerFarmer(name, email, password);
            case 2 -> userService.registerSeller(name, email, password);
            case 3 -> userService.registerBuyer(name, email, password);
            case 4 -> userService.registerAdmin(name, email, password);
            default -> null;
        };
        if (u != null) {
            System.out.println("Registered: " + u);
        } else {
            System.out.println("Invalid role.");
        }
    }

    // ---------------------------------------------------------------- MAIN

    private static void mainMenu() {
        System.out.println("\n--- " + currentUser.dashboardSummary() + " ---");
        List<String> options = new ArrayList<>();
        options.add("Logout");
        options.add("View my notifications");

        if (currentUser instanceof Farmer) {
            options.add("Get crop advisory");
            options.add("View my advisories");
        }
        if (currentUser instanceof Seller) {
            options.add("List a new product");
            options.add("View my listings");
        }
        if (currentUser instanceof Buyer) {
            options.add("Browse marketplace");
            options.add("Place an order");
            options.add("View my orders");
        }
        if (currentUser instanceof Admin) {
            options.add("Issue weather alert");
            options.add("View all users");
            options.add("Generate reports");
        }

        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
        int choice = readInt("Choose: ") - 1;
        if (choice < 0 || choice >= options.size()) {
            System.out.println("Invalid choice.");
            return;
        }
        handleChoice(options.get(choice));
    }

    private static void handleChoice(String choice) {
        switch (choice) {
            case "Logout" -> {
                currentUser.logout();
                currentUser = null;
            }
            case "View my notifications" -> currentUser.getInbox().forEach(System.out::println);
            case "Get crop advisory" -> handleAdvisory();
            case "View my advisories" -> ((Farmer) currentUser).getAdvisories().forEach(System.out::println);
            case "List a new product" -> handleListProduct();
            case "View my listings" -> ((Seller) currentUser).getListings().forEach(System.out::println);
            case "Browse marketplace" -> marketService.getAllActive().forEach(System.out::println);
            case "Place an order" -> handlePlaceOrder();
            case "View my orders" -> ((Buyer) currentUser).getOrders().forEach(o -> System.out.println(orderService.generateInvoice(o)));
            case "Issue weather alert" -> handleWeatherAlert();
            case "View all users" -> userService.getAllUsers().forEach(System.out::println);
            case "Generate reports" -> handleReports();
        }
    }

    // ------------------------------------------------------------ MODULE 2

    private static void handleAdvisory() {
        String crop = readLine("Crop name: ");
        String soil = readLine("Soil type (clay/sandy/loamy/silty): ");
        CropAdvisory advisory = advisoryService.generateAdvisory((Farmer) currentUser, crop, soil);
        System.out.println("Advisory: " + advisory.getRecommendation());
    }

    // ------------------------------------------------------------ MODULE 3

    private static void handleListProduct() {
        String name = readLine("Product name: ");
        String category = readLine("Category: ");
        double price = readDouble("Price: ");
        int qty = readInt("Quantity: ");
        Product p = marketService.addListing((Seller) currentUser, name, category, price, qty);
        System.out.println("Listed: " + p);
    }

    // ------------------------------------------------------------ MODULE 5

    private static void handlePlaceOrder() {
        List<Product> catalog = marketService.getAllActive();
        if (catalog.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        catalog.forEach(System.out::println);
        int productId = readInt("Enter product # to buy: ");
        Product chosen = catalog.stream().filter(p -> p.getId() == productId).findFirst().orElse(null);
        if (chosen == null) {
            System.out.println("Product not found.");
            return;
        }
        int qty = readInt("Quantity: ");
        try {
            Order order = orderService.placeOrder((Buyer) currentUser, List.of(new OrderItem(chosen, qty)));
            System.out.println("Pay with: 1. Card  2. Mobile Money");
            Payment payment;
            if (readInt("Choose: ") == 1) {
                payment = new CardPayment(order, order.total(), readLine("Card last 4 digits: "));
            } else {
                payment = new MobileMoneyPayment(order, order.total(), readLine("Phone number: "));
            }
            boolean ok = orderService.pay(order, payment);
            System.out.println(ok ? "Payment successful!" : "Payment failed.");
            System.out.println(orderService.generateInvoice(order));
        } catch (IllegalArgumentException e) {
            System.out.println("Could not place order: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ MODULE 4

    private static void handleWeatherAlert() {
        String region = readLine("Region: ");
        String desc = readLine("Description: ");
        System.out.println("Severity: 1. INFO  2. WARNING  3. DISASTER");
        WeatherAlert.Severity sev = switch (readInt("Choose: ")) {
            case 2 -> WeatherAlert.Severity.WARNING;
            case 3 -> WeatherAlert.Severity.DISASTER;
            default -> WeatherAlert.Severity.INFO;
        };
        WeatherAlert alert = weatherService.issueAlert(region, desc, sev);
        List<Farmer> farmers = userService.getAllUsers().stream()
                .filter(u -> u instanceof Farmer).map(u -> (Farmer) u).toList();
        weatherService.broadcastToFarmers(alert, farmers);
        System.out.println("Alert broadcast to " + farmers.size() + " farmer(s).");
    }

    // ------------------------------------------------------------ MODULE 6

    private static void handleReports() {
        System.out.println(reportService.salesReport(orderService.getAllOrders()));
        System.out.println();
        System.out.println(reportService.userReport(userService));
        System.out.println();
        List<Seller> sellers = userService.getAllUsers().stream()
                .filter(u -> u instanceof Seller).map(u -> (Seller) u).toList();
        System.out.println(reportService.topSellersReport(sellers));
        notifier.printAuditLog();
    }

    // -------------------------------------------------------------- INPUT

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readLine(prompt));
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            try {
                return Double.parseDouble(readLine(prompt));
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    // --------------------------------------------------------- DEMO SEED

    /** Seeds a couple of accounts/products so the app is usable immediately. */
    private static void seedDemoData() {
        Farmer john = userService.registerFarmer("John Otieno", "john@farm.com", "pass123");
        Seller mary = userService.registerSeller("Mary AgriSupplies", "mary@shop.com", "pass123");
        userService.registerBuyer("Alice Buyer", "alice@buy.com", "pass123");
        userService.registerAdmin("Admin", "admin@agriconnect.com", "admin123");

        marketService.addListing(mary, "Hybrid Maize Seeds", "Seeds", 12.50, 100);
        marketService.addListing(mary, "NPK Fertilizer 50kg", "Fertilizer", 35.00, 40);

        advisoryService.generateAdvisory(john, "Maize", "loamy");

        System.out.println("(Demo accounts ready — try john@farm.com / mary@shop.com / alice@buy.com / admin@agriconnect.com, all with the passwords shown in code)");
    }
}
