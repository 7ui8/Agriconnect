package com.agriconnect.common;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the "COMMON SERVICES" box in the architecture:
 * Notifications | Email/SMS | Audit Logs | Activity Logging | Error Handling.
 *
 * Implemented as a Singleton since every module shares the same service.
 */
public class NotificationService {

    private static NotificationService instance;
    private final List<String> auditLog = new ArrayList<>();

    private NotificationService() {
    }

    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    public void notify(Notifiable recipient, String message) {
        recipient.receiveNotification(message);
        log("NOTIFY -> " + recipient.getContactName() + ": " + message);
    }

    public void log(String entry) {
        auditLog.add("[" + LocalDateTime.now() + "] " + entry);
    }

    public void logError(String context, Exception e) {
        auditLog.add("[" + LocalDateTime.now() + "] ERROR in " + context + ": " + e.getMessage());
    }

    public void printAuditLog() {
        System.out.println("\n--- AUDIT LOG ---");
        auditLog.forEach(System.out::println);
    }
}
