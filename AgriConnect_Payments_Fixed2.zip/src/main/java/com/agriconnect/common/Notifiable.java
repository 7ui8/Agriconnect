package com.agriconnect.common;

/**
 * Any object that can receive a notification (Notifications / Email / SMS
 * from the "Common Services" block in the architecture diagram).
 */
public interface Notifiable {
    String getContactName();
    void receiveNotification(String message);
}
