package com.agriconnect.model;

public class CardPayment extends Payment {

    private final String cardLastFour;

    public CardPayment(Order order, double amount, String cardLastFour) {
        super(order, amount);
        this.cardLastFour = cardLastFour;
    }

    @Override
    public boolean process() {
        // Simulated call to external Payment Gateway service
        boolean success = cardLastFour != null && cardLastFour.length() == 4;
        setStatus(success ? Status.SUCCESS : Status.FAILED);
        return success;
    }
}
