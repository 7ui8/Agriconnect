package com.agriconnect.model;

import java.util.ArrayList;
import java.util.List;

public class Buyer extends User {

    private final List<Order> orders = new ArrayList<>();

    public Buyer(String name, String email, String password) {
        super(name, email, password, Role.BUYER);
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }

    @Override
    public String dashboardSummary() {
        double spent = orders.stream().mapToDouble(Order::total).sum();
        return getName() + " (Buyer) - " + orders.size() + " orders, total spent: ₹"
                + String.format("%.2f", spent);
    }
}
