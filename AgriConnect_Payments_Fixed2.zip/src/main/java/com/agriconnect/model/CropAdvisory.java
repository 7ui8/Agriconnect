package com.agriconnect.model;

import java.time.LocalDate;

/**
 * Module 2: Crop Advisory & Recommendation.
 * Holds a soil analysis + weather-based recommendation for a farmer's crop.
 */
public class CropAdvisory {

    private final Farmer farmer;
    private final String cropName;
    private final String soilType;
    private final String recommendation;
    private final LocalDate issuedOn;

    public CropAdvisory(Farmer farmer, String cropName, String soilType, String recommendation) {
        this.farmer = farmer;
        this.cropName = cropName;
        this.soilType = soilType;
        this.recommendation = recommendation;
        this.issuedOn = LocalDate.now();
    }

    public Farmer getFarmer() {
        return farmer;
    }

    public String getCropName() {
        return cropName;
    }

    public String getRecommendation() {
        return recommendation;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | crop: %s | soil: %s -> %s",
                issuedOn, farmer.getName(), cropName, soilType, recommendation);
    }
}
