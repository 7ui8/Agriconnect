package com.agriconnect.model;

/**
 * Represents a payment attempt for an Order. Subclasses model different
 * payment methods (Card, MobileMoney) -> demonstrates polymorphism, tying
 * into the "Payment Gateway" external service in the architecture diagram.
 */
public abstract class Payment {

    public enum Status { PENDING, SUCCESS, FAILED, REFUNDED }

    private final Order order;
    private final double amount;
    private Status status;

    protected Payment(Order order, double amount) {
        this.order = order;
        this.amount = amount;
        this.status = Status.PENDING;
    }

    // Each payment method implements its own gateway call
    public abstract boolean process();

    public void refund() {
        status = Status.REFUNDED;
    }

    protected void setStatus(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

    public double getAmount() {
        return amount;
    }

    public Order getOrder() {
        return order;
    }
}
