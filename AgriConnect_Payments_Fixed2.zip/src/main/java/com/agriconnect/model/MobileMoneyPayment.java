package com.agriconnect.model;

public class MobileMoneyPayment extends Payment {

    private final String phoneNumber;

    public MobileMoneyPayment(Order order, double amount, String phoneNumber) {
        super(order, amount);
        this.phoneNumber = phoneNumber;
    }

    @Override
    public boolean process() {
        boolean success = phoneNumber != null && phoneNumber.length() >= 9;
        setStatus(success ? Status.SUCCESS : Status.FAILED);
        return success;
    }
}
