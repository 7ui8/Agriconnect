package com.agriconnect.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Order {

    public enum Status { PLACED, PAID, SHIPPED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED }

    private static int nextId = 1;

    private final int id;
    private final Buyer buyer;
    private final List<OrderItem> items = new ArrayList<>();
    private Status status;
    private Payment payment;
    private final LocalDateTime createdAt;
    private LocalDateTime statusUpdatedAt;

    public Order(Buyer buyer) {
        this.id = nextId++;
        this.buyer = buyer;
        this.status = Status.PLACED;
        this.createdAt = LocalDateTime.now();
        this.statusUpdatedAt = this.createdAt;
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    public double total() {
        return items.stream().mapToDouble(OrderItem::subtotal).sum();
    }

    public void attachPayment(Payment payment) {
        this.payment = payment;
        if (payment.getStatus() == Payment.Status.SUCCESS) {
            setStatus(Status.PAID);
        }
    }

    public void setStatus(Status status) {
        this.status = status;
        this.statusUpdatedAt = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public Buyer getBuyer() {
        return buyer;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public Status getStatus() {
        return status;
    }

    public Payment getPayment() {
        return payment;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getStatusUpdatedAt() {
        return statusUpdatedAt;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Order #%d | buyer: %s | status: %s | total: ₹%.2f%n",
                id, buyer.getName(), status, total()));
        for (OrderItem item : items) {
            sb.append("    - ").append(item).append("\n");
        }
        return sb.toString();
    }
}
