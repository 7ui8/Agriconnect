package com.agriconnect.model;

import java.time.LocalDateTime;

public class WeatherAlert {

    public enum Severity { INFO, WARNING, DISASTER }

    private final String region;
    private final String description;
    private final Severity severity;
    private final LocalDateTime issuedAt;

    public WeatherAlert(String region, String description, Severity severity) {
        this.region = region;
        this.description = description;
        this.severity = severity;
        this.issuedAt = LocalDateTime.now();
    }

    public String getRegion() {
        return region;
    }

    public Severity getSeverity() {
        return severity;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return String.format("[%s][%s] %s: %s", issuedAt.toLocalDate(), severity, region, description);
    }
}
