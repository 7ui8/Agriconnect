package com.agriconnect.model;

import java.time.LocalDateTime;

public class Report {

    private final String title;
    private final String content;
    private final LocalDateTime generatedAt;

    public Report(String title, String content) {
        this.title = title;
        this.content = content;
        this.generatedAt = LocalDateTime.now();
    }

    public String getTitle() { return title; }
    public String getContent() { return content; }

    @Override
    public String toString() {
        return "===== " + title + " (" + generatedAt.toLocalDate() + ") =====\n" + content;
    }
}
