package com.agriconnect.model;

import com.agriconnect.common.Notifiable;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract superclass for every account type in the system.
 * Covers Module 1 (User Management): Registration, Login/Logout,
 * Role Management, Profile Management.
 */
public abstract class User implements Notifiable {

    private static int nextId = 1;

    private final int id;
    private String name;
    private String email;
    private String password;
    private final Role role;
    private boolean loggedIn;
    private final List<String> inbox = new ArrayList<>();

    protected User(String name, String email, String password, Role role) {
        this.id = nextId++;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.loggedIn = false;
    }

    public boolean login(String password) {
        if (this.password.equals(password)) {
            loggedIn = true;
        }
        return loggedIn;
    }

    public void logout() {
        loggedIn = false;
    }

    public void updateProfile(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Every subclass presents its own dashboard summary -> polymorphism
    public abstract String dashboardSummary();

    @Override
    public String getContactName() {
        return name;
    }

    @Override
    public void receiveNotification(String message) {
        inbox.add(message);
    }

    public List<String> getInbox() {
        return inbox;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public Role getRole() {
        return role;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    @Override
    public String toString() {
        return String.format("[#%d] %s (%s) <%s>", id, name, role, email);
    }
}
