package com.agriconnect.model;

public enum Role {
    FARMER,
    SELLER,
    BUYER,
    ADMIN
}
