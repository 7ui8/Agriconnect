package com.agriconnect.model;

public class Product {

    private static int nextId = 1;

    private final int id;
    private String name;
    private String category;
    private double price;
    private int quantity;
    private final User seller;
    private boolean active;

    // Marketplace details added for real farm-to-consumer listings.
    private String unit;
    private String farmName;
    private String location;
    private String description;
    private String harvestDate;
    private String photoUrl;

    public Product(String name, String category, double price, int quantity, User seller) {
        this(name, category, price, quantity, seller, "kg",
                seller == null ? "" : seller.getName() + "'s Farm", "",
                "", "", "");
    }

    public Product(String name, String category, double price, int quantity, User seller,
                   String unit, String farmName, String location, String description,
                   String harvestDate, String photoUrl) {
        this.id = nextId++;
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.seller = seller;
        this.active = true;
        this.unit = clean(unit, "kg");
        this.farmName = clean(farmName, seller == null ? "" : seller.getName() + "'s Farm");
        this.location = clean(location, "");
        this.description = clean(description, "");
        this.harvestDate = clean(harvestDate, "");
        this.photoUrl = clean(photoUrl, "");
    }

    private static String clean(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    public void reduceStock(int amount) {
        if (amount > quantity) throw new IllegalArgumentException("Not enough stock for " + name);
        quantity -= amount;
        if (quantity == 0) active = false;
    }

    public void restock(int amount) {
        quantity += amount;
        active = true;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public User getSeller() { return seller; }
    public boolean isActive() { return active; }
    public String getUnit() { return unit; }
    public String getFarmName() { return farmName; }
    public String getLocation() { return location; }
    public String getDescription() { return description; }
    public String getHarvestDate() { return harvestDate; }
    public String getPhotoUrl() { return photoUrl; }

    public void setPrice(double price) {
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative.");
        this.price = price;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) throw new IllegalArgumentException("Quantity cannot be negative.");
        this.quantity = quantity;
        this.active = quantity > 0;
    }

    public void setUnit(String unit) { this.unit = clean(unit, "kg"); }
    public void setFarmName(String farmName) { this.farmName = clean(farmName, seller.getName() + "'s Farm"); }
    public void setLocation(String location) { this.location = clean(location, ""); }
    public void setDescription(String description) { this.description = clean(description, ""); }
    public void setHarvestDate(String harvestDate) { this.harvestDate = clean(harvestDate, ""); }
    public void setPhotoUrl(String photoUrl) {
        if (photoUrl != null && photoUrl.length() > 2_000_000)
            throw new IllegalArgumentException("Product photo is too large. Please use an image under 1.5 MB.");
        this.photoUrl = clean(photoUrl, "");
    }

    public void deactivate() { this.active = false; }

    @Override
    public String toString() {
        return String.format("#%d %-15s ₹%-8.2f qty:%-4d %s seller:%s",
                id, name, price, quantity, unit, seller.getName());
    }
}
