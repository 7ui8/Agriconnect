package com.agriconnect.model;

/** Simulated UPI payment strategy. Replace process() with a real PSP/gateway call for production. */
public class UpiPayment extends Payment {
    private final String upiId;
    public UpiPayment(Order order, double amount, String upiId) { super(order, amount); this.upiId = upiId; }
    public String getUpiId() { return upiId; }
    @Override public boolean process() {
        boolean success = upiId != null && upiId.matches("[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}");
        setStatus(success ? Status.SUCCESS : Status.FAILED);
        return success;
    }
}
