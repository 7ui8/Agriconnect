package com.agriconnect.model;

import java.util.ArrayList;
import java.util.List;

public class Seller extends User {

    private final List<Product> listings = new ArrayList<>();
    private double totalRevenue = 0.0;

    public Seller(String name, String email, String password) {
        super(name, email, password, Role.SELLER);
    }

    public Product listProduct(String name, String category, double price, int quantity) {
        return listProduct(name, category, price, quantity, "kg", getName() + "'s Farm",
                "", "", "", "");
    }

    public Product listProduct(String name, String category, double price, int quantity,
                               String unit, String farmName, String location,
                               String description, String harvestDate, String photoUrl) {
        Product p = new Product(name, category, price, quantity, this, unit, farmName,
                location, description, harvestDate, photoUrl);
        listings.add(p);
        return p;
    }

    public void addRevenue(double amount) {
        totalRevenue += amount;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public List<Product> getListings() {
        return listings;
    }

    @Override
    public String dashboardSummary() {
        return getName() + " (Seller) - " + listings.size() + " listings, revenue: ₹"
                + String.format("%.2f", totalRevenue);
    }
}
