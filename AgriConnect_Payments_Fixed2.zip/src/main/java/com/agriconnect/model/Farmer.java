package com.agriconnect.model;

import java.util.ArrayList;
import java.util.List;

public class Farmer extends User {

    private final List<CropAdvisory> advisories = new ArrayList<>();
    private final List<Product> listings = new ArrayList<>();
    private double totalRevenue = 0.0;

    public Farmer(String name, String email, String password) {
        super(name, email, password, Role.FARMER);
    }

    public void addAdvisory(CropAdvisory advisory) {
        advisories.add(advisory);
    }

    public List<CropAdvisory> getAdvisories() {
        return advisories;
    }

    public Product listProduct(String name, String category, double price, int quantity) {
        return listProduct(name, category, price, quantity, "kg", getName() + "'s Farm",
                "", "", "", "");
    }

    public Product listProduct(String name, String category, double price, int quantity,
                               String unit, String farmName, String location,
                               String description, String harvestDate, String photoUrl) {
        Product p = new Product(name, category, price, quantity, this, unit, farmName,
                location, description, harvestDate, photoUrl);
        listings.add(p);
        return p;
    }

    public List<Product> getListings() { return listings; }

    public void addRevenue(double amount) { totalRevenue += amount; }

    public double getTotalRevenue() { return totalRevenue; }

    @Override
    public String dashboardSummary() {
        return getName() + " (Farmer) - " + listings.size() + " products listed, revenue: ₹"
                + String.format("%.2f", totalRevenue) + ", " + advisories.size() + " crop advisories received.";
    }
}
