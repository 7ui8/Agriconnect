package com.agriconnect.model;

public class Admin extends User {

    public Admin(String name, String email, String password) {
        super(name, email, password, Role.ADMIN);
    }

    @Override
    public String dashboardSummary() {
        return getName() + " (Admin) - manages users, content & reports.";
    }
}
