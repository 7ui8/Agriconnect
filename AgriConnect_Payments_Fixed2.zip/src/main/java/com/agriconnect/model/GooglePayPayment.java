package com.agriconnect.model;

/** Simulated Google Pay/UPI payment strategy. Real GPay payments require a payment provider integration. */
public class GooglePayPayment extends Payment {
    private final String upiId;
    public GooglePayPayment(Order order, double amount, String upiId) { super(order, amount); this.upiId = upiId; }
    public String getUpiId() { return upiId; }
    @Override public boolean process() {
        boolean success = upiId != null && upiId.matches("[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}");
        setStatus(success ? Status.SUCCESS : Status.FAILED);
        return success;
    }
}
