package com.agriconnect.service;

import com.agriconnect.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Module 1: User Management - Registration, Login/Logout, Role Management,
 * Profile Management.
 */
public class UserService {

    private final List<User> users = new ArrayList<>();

    public Farmer registerFarmer(String name, String email, String password) {
        Farmer f = new Farmer(name, email, password);
        users.add(f);
        return f;
    }

    public Seller registerSeller(String name, String email, String password) {
        Seller s = new Seller(name, email, password);
        users.add(s);
        return s;
    }

    public Buyer registerBuyer(String name, String email, String password) {
        Buyer b = new Buyer(name, email, password);
        users.add(b);
        return b;
    }

    public Admin registerAdmin(String name, String email, String password) {
        Admin a = new Admin(name, email, password);
        users.add(a);
        return a;
    }

    public Optional<User> login(String email, String password) {
        return users.stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .filter(u -> u.login(password))
                .findFirst();
    }

    public List<User> getAllUsers() {
        return users;
    }

    public long countByRole(Role role) {
        return users.stream().filter(u -> u.getRole() == role).count();
    }
}
