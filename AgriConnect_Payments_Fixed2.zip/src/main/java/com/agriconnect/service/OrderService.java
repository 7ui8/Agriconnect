package com.agriconnect.service;

import com.agriconnect.common.NotificationService;
import com.agriconnect.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 5: Orders & Payments - Order Management, Payment Processing,
 * Invoice Generation, Refund Management.
 */
public class OrderService {

    private final List<Order> orders = new ArrayList<>();
    private final NotificationService notifier = NotificationService.getInstance();

    public Order placeOrder(Buyer buyer, List<OrderItem> items) {
        Order order = new Order(buyer);
        for (OrderItem item : items) {
            item.getProduct().reduceStock(item.getQuantity());
            order.addItem(item);
        }
        orders.add(order);
        buyer.addOrder(order);
        notifier.notify(buyer, "Order #" + order.getId() + " placed. Total: ₹"
                + String.format("%.2f", order.total()));
        return order;
    }

    /** Pay for an order using any Payment strategy (Card, Mobile Money, ...). */
    public boolean pay(Order order, Payment payment) {
        boolean success = payment.process();
        order.attachPayment(payment);
        if (success) {
            for (OrderItem item : order.getItems()) {
                User owner = item.getProduct().getSeller();
                if (owner instanceof Seller seller) seller.addRevenue(item.subtotal());
                if (owner instanceof Farmer farmer) farmer.addRevenue(item.subtotal());
            }
            notifier.notify(order.getBuyer(), "Payment successful for Order #" + order.getId());
        } else {
            notifier.notify(order.getBuyer(), "Payment FAILED for Order #" + order.getId());
        }
        return success;
    }

    public void refund(Order order) {
        if (order.getPayment() != null) {
            order.getPayment().refund();
            order.setStatus(Order.Status.CANCELLED);
            notifier.notify(order.getBuyer(), "Order #" + order.getId() + " has been refunded.");
        }
    }

    public String generateInvoice(Order order) {
        StringBuilder sb = new StringBuilder();
        sb.append("INVOICE - Order #").append(order.getId()).append("\n");
        sb.append("Buyer: ").append(order.getBuyer().getName()).append("\n");
        for (OrderItem item : order.getItems()) {
            sb.append("  ").append(item).append("\n");
        }
        sb.append("TOTAL: ₹").append(String.format("%.2f", order.total())).append("\n");
        sb.append("Status: ").append(order.getStatus());
        return sb.toString();
    }

    public List<Order> getAllOrders() {
        return orders;
    }
}
