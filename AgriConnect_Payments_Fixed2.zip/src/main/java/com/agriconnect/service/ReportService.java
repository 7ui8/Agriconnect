package com.agriconnect.service;

import com.agriconnect.model.*;

import java.util.List;

/**
 * Module 6: Reports & Analytics - Data Analytics, Reports Generation,
 * Dashboards, Export Reports.
 */
public class ReportService {

    public Report salesReport(List<Order> orders) {
        double totalRevenue = orders.stream()
                .filter(o -> o.getStatus() != Order.Status.CANCELLED)
                .mapToDouble(Order::total)
                .sum();
        long paidOrders = orders.stream().filter(o -> o.getStatus() == Order.Status.PAID).count();

        String content = String.format(
                "Total Orders: %d%nPaid Orders: %d%nTotal Revenue: ₹%.2f",
                orders.size(), paidOrders, totalRevenue);
        return new Report("Sales Report", content);
    }

    public Report userReport(UserService userService) {
        StringBuilder sb = new StringBuilder();
        for (Role role : Role.values()) {
            sb.append(role).append(": ").append(userService.countByRole(role)).append("\n");
        }
        return new Report("User Report", sb.toString().trim());
    }

    public Report topSellersReport(List<Seller> sellers) {
        StringBuilder sb = new StringBuilder();
        sellers.stream()
                .sorted((a, b) -> Double.compare(b.getTotalRevenue(), a.getTotalRevenue()))
                .forEach(s -> sb.append(s.getName())
                        .append(" - ₹")
                        .append(String.format("%.2f", s.getTotalRevenue()))
                        .append("\n"));
        return new Report("Top Sellers Report", sb.toString().trim());
    }
}
