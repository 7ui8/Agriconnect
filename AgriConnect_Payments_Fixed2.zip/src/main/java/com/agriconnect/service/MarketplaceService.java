package com.agriconnect.service;

import com.agriconnect.model.Product;
import com.agriconnect.model.Seller;
import com.agriconnect.model.User;
import com.agriconnect.model.Farmer;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 3: Marketplace (Buy/Sell) - Product/Input listing, Search & Filters,
 * Add to Cart, Buy/Sell.
 */
public class MarketplaceService {

    private final List<Product> catalog = new ArrayList<>();

    public Product addListing(User seller, String name, String category, double price, int quantity) {
        return addListing(seller, name, category, price, quantity, "kg",
                seller == null ? "" : seller.getName() + "'s Farm", "", "", "", "");
    }

    public Product addListing(User seller, String name, String category, double price, int quantity,
                              String unit, String farmName, String location,
                              String description, String harvestDate, String photoUrl) {
        if (!(seller instanceof Seller) && !(seller instanceof Farmer)) {
            throw new IllegalArgumentException("Only farmers and sellers can add products.");
        }
        Product p = seller instanceof Seller s
                ? s.listProduct(name, category, price, quantity, unit, farmName, location, description, harvestDate, photoUrl)
                : ((Farmer) seller).listProduct(name, category, price, quantity, unit, farmName, location, description, harvestDate, photoUrl);
        catalog.add(p);
        return p;
    }

    public List<Product> searchByName(String keyword) {
        return catalog.stream()
                .filter(Product::isActive)
                .filter(p -> p.getName().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }

    public List<Product> filterByCategory(String category) {
        return catalog.stream()
                .filter(Product::isActive)
                .filter(p -> p.getCategory().equalsIgnoreCase(category))
                .toList();
    }

    public List<Product> getAllActive() {
        return catalog.stream().filter(Product::isActive).toList();
    }

    public List<Product> getCatalog() {
        return catalog;
    }
}
