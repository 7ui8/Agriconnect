package com.agriconnect.service;

import com.agriconnect.common.NotificationService;
import com.agriconnect.model.CropAdvisory;
import com.agriconnect.model.Farmer;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 2: Crop Advisory & Recommendation - Soil Analysis, Weather
 * Analysis, Crop Recommendation, Advisory Generation.
 */
public class CropAdvisoryService {

    private final List<CropAdvisory> advisories = new ArrayList<>();
    private final NotificationService notifier = NotificationService.getInstance();

    /** Very simple rule-based recommendation engine. */
    public CropAdvisory generateAdvisory(Farmer farmer, String cropName, String soilType) {
        String recommendation = recommend(soilType);
        CropAdvisory advisory = new CropAdvisory(farmer, cropName, soilType, recommendation);
        advisories.add(advisory);
        farmer.addAdvisory(advisory);
        notifier.notify(farmer, "New crop advisory for " + cropName + ": " + recommendation);
        return advisory;
    }

    private String recommend(String soilType) {
        return switch (soilType.toLowerCase()) {
            case "clay" -> "Add organic compost, improve drainage, plant rice/wheat.";
            case "sandy" -> "Use frequent light irrigation, add mulch, plant groundnut/millet.";
            case "loamy" -> "Ideal soil - suitable for most crops, maintain regular fertilization.";
            case "silty" -> "Good fertility - watch for compaction, plant leafy vegetables.";
            default -> "Get a soil test done for a precise recommendation.";
        };
    }

    public List<CropAdvisory> getAllAdvisories() {
        return advisories;
    }
}
