package com.agriconnect.service;

import com.agriconnect.common.NotificationService;
import com.agriconnect.model.Farmer;
import com.agriconnect.model.WeatherAlert;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 4: Weather & Alerts - Weather Updates, Forecasts, Alerts &
 * Notifications, Disaster Warnings. Simulates the "Weather API" external
 * service and pushes alerts through the Common Services notifier.
 */
public class WeatherService {

    private final List<WeatherAlert> alerts = new ArrayList<>();
    private final NotificationService notifier = NotificationService.getInstance();

    public WeatherAlert issueAlert(String region, String description, WeatherAlert.Severity severity) {
        WeatherAlert alert = new WeatherAlert(region, description, severity);
        alerts.add(alert);
        return alert;
    }

    /** Push an alert to every farmer in the affected region. */
    public void broadcastToFarmers(WeatherAlert alert, List<Farmer> farmers) {
        for (Farmer f : farmers) {
            notifier.notify(f, "WEATHER ALERT (" + alert.getSeverity() + "): " + alert.getDescription());
        }
    }

    public List<WeatherAlert> getAlerts() {
        return alerts;
    }
}
