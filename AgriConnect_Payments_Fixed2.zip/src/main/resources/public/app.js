const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={user:null,products:[],cart:null};
const money=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n||0));
async function api(path,opts={}){const r=await fetch(path,{credentials:"include",headers:{"Content-Type":"application/json",...(opts.headers||{})},...opts});let d=null;try{d=await r.json()}catch{}if(!r.ok)throw new Error(d?.error||"Something went wrong");return d}
function toast(msg){$("#toast").innerHTML=`<div class="toast">${esc(msg)}</div>`;setTimeout(()=>$("#toast").innerHTML="",2800)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function icon(cat){return ({Seeds:"🌱",Fertilizer:"🪴","Crop Protection":"🛡️"})[cat]||"🌾"}
function productImage(p){if(p.photoUrl)return p.photoUrl;const q={Seeds:"photo-1416879595882-3373a0480b5b",Fertilizer:"photo-1589923188900-85dae523342b","Crop Protection":"photo-1492496913980-501348b61469","Fresh Produce":"photo-1546094096-0df4bcaaa337",Vegetables:"photo-1546094096-0df4bcaaa337",Fruits:"photo-1560806887-1e4cd0b6cbd6",Grains:"photo-1574323347407-f5e1ad6d020b"}[p.category]||"photo-1464226184884-fa280b87c399";return `https://images.unsplash.com/${q}?auto=format&fit=crop&w=900&q=80`}
async function boot(){try{state.user=await api("/api/me");showApp();await refreshAll()}catch{showAuth()}}
function showAuth(){$("#authScreen").classList.remove("hidden");$("#app").classList.add("hidden")}
function showApp(){$("#authScreen").classList.add("hidden");$("#app").classList.remove("hidden");$("#userName").textContent=state.user.name;$("#userRole").textContent=state.user.role;$("#profileChip .avatar").textContent=state.user.name[0]?.toUpperCase()||"A";$$(".farmer-only,.buyer-only,.admin-only,.seller-only").forEach(e=>e.classList.add("hidden"));const role=state.user.role.toLowerCase();$$(`.${role}-only`).forEach(e=>e.classList.remove("hidden"));$("#roleWelcome").textContent={FARMER:"List your harvest, reach buyers directly, review crop advice and grow your farm income.",SELLER:"Manage your listings, reach buyers and grow your farm-business revenue.",BUYER:"Discover useful farm products, shop from sellers and track every order.",ADMIN:"Keep the marketplace healthy and help farmers stay informed."}[state.user.role]}
async function refreshAll(){await Promise.all([loadDashboard(),loadProducts(),loadAlerts(),loadNotifications()]);if(state.user.role==="BUYER")loadOrders();if(state.user.role==="FARMER")loadAdvisories();if(state.user.role==="FARMER"||state.user.role==="SELLER"){loadListings();loadSales()}if(state.user.role==="ADMIN"){loadReports();loadUsers()}}
async function loadAlerts(){
  try{
    const alerts=await api("/api/alerts");
    $("#alerts").innerHTML=alerts.length?alerts.slice().reverse().map(a=>`<div class="alert-item"><div class="alert-icon">⚠️</div><div><strong>${esc(a.severity||"INFO")}</strong><p>${esc(a.description||"")}</p><small>${esc(a.region||"India")} · ${esc(a.issuedAt||"").replace("T"," ").slice(0,16)}</small></div></div>`).join(""):`<div class="empty">No weather alerts right now.</div>`;
  }catch(e){
    $("#alerts").innerHTML=`<div class="empty">Unable to load alerts.</div>`;
  }
}
function updatePaymentField(){
  const method=$("#payMethod").value;
  const input=$("#payValue");
  if(method==="card"){
    input.type="text"; input.inputMode="numeric"; input.maxLength=4; input.placeholder="Last 4 card digits";
  }else{
    input.type="text"; input.inputMode="email"; input.maxLength=100; input.placeholder=method==="gpay"?"Google Pay UPI ID (e.g. name@upi)":"UPI ID (e.g. name@upi)";
  }
  input.value="";
}
async function loadNotifications(){
  try{
    const items=await api("/api/notifications");
    const list=Array.isArray(items)?items:[];
    $("#notifications").innerHTML=list.length
      ? list.slice().reverse().map(n=>`<div class="notification-item"><div class="notification-icon">🔔</div><div><p>${esc(typeof n==="string"?n:(n.message||n.description||JSON.stringify(n)))}</p></div></div>`).join("")
      : `<div class="empty">No new notifications.</div>`;
    const dot=$("#notifDot");
    if(dot) dot.classList.toggle("hidden",list.length===0);
  }catch(e){
    $("#notifications").innerHTML=`<div class="empty">Unable to load notifications.</div>`;
  }
}
async function loadDashboard(){const d=await api("/api/dashboard");const cards=[];if(state.user.role==="BUYER"){cards.push(["Orders",d.orderCount||0],["Total spent",money(d.spent)],["Available products",d.productCount||0],["Account","Buyer"])}else if(state.user.role==="SELLER"){cards.push(["Listings",d.listingCount||0],["Sales",d.salesCount||0],["Revenue",money(d.revenue)],["Account","Seller"])}else if(state.user.role==="FARMER"){cards.push(["My products",d.listingCount||0],["Sales",d.salesCount||0],["Sales revenue",money(d.revenue)],["Advisories",d.advisoryCount||0])}else{cards.push(["Users",d.users||0],["Orders",d.orders||0],["Products",d.productCount||0],["Account","Admin"])}$("#stats").innerHTML=cards.map(x=>`<div class="stat"><small>${x[0]}</small><strong>${x[1]}</strong></div>`).join("")}
async function loadProducts(){state.products=await api("/api/products");renderFeatured();renderProducts()}
function renderFeatured(){$("#featuredProducts").innerHTML=state.products.slice(0,4).map(p=>`<div class="product-mini"><div class="prod-icon">${icon(p.category)}</div><div><h4>${esc(p.name)}</h4><small>${esc(p.farmName||p.seller)} • ${p.quantity} ${esc(p.unit||"kg")} available</small><strong>${money(p.price)} / ${esc(p.unit||"unit")}</strong></div></div>`).join("")||`<div class="empty">No products yet.</div>`}
function renderProducts(){const q=$("#search").value.toLowerCase().trim(),cat=$("#category").value;const ps=state.products.filter(p=>(!q||p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q)||String(p.farmName||"").toLowerCase().includes(q))&&(!cat||p.category===cat));$("#products").innerHTML=ps.map(p=>`<article class="product-card"><div class="product-image" style="background-image:url('${productImage(p)}')"><span class="photo-badge">${p.photoUrl?"Farm photo":"AgriConnect"}</span></div><div class="product-body"><span class="tag">${esc(p.category)}</span><h3>${esc(p.name)}</h3><p>${esc(p.description||"Fresh farm product.")}</p><div class="farm-line">🌾 ${esc(p.farmName||p.seller)} · ${esc(p.location||"India")}</div><div class="stock-line">${p.quantity} ${esc(p.unit||"kg")} available${p.harvestDate?` · Harvest ${esc(p.harvestDate)}`:""}</div><div class="price-row"><span class="price">${money(p.price)} <small>/ ${esc(p.unit||"unit")}</small></span><button class="add-btn" onclick="addToCart(${p.id})" title="Add to cart">+</button></div></div></article>`).join("")||`<div class="empty" style="grid-column:1/-1">No products match your search.</div>`}
function addToCart(id){if(state.user.role!=="BUYER"){toast("Only buyer accounts can place orders.");return}const p=state.products.find(x=>x.id===id);state.cart={product:p,quantity:1};openCart()}
function openCart(){if(!state.cart)return;$("#cartItems").innerHTML=`<div class="cart-row"><div><b>${esc(state.cart.product.name)}</b><small>${esc(state.cart.product.farmName||state.cart.product.seller)} · ${money(state.cart.product.price)} / ${esc(state.cart.product.unit||"unit")}</small></div><div><input id="cartQty" type="number" min="1" max="${state.cart.product.quantity}" value="${state.cart.quantity}" style="width:70px;padding:8px;border:1px solid #ddd;border-radius:8px"></div></div>`;$("#cartTotal").textContent=money(state.cart.product.price*state.cart.quantity);$("#cartDrawer").classList.remove("hidden");$("#drawerBackdrop").classList.remove("hidden");$("#cartQty").oninput=e=>{state.cart.quantity=Math.max(1,Math.min(state.cart.product.quantity,Number(e.target.value)||1));$("#cartTotal").textContent=money(state.cart.product.price*state.cart.quantity)}}
async function checkout(){
  if(!state.cart)return;
  const method=$("#payMethod").value,v=$("#payValue").value.trim();
  const upiPattern=/^[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}$/;
  if(method==="card"&&!/^\d{4}$/.test(v)){toast("Enter exactly the last 4 digits of your card.");return}
  if((method==="upi"||method==="gpay")&&!upiPattern.test(v)){toast("Enter a valid UPI ID, for example name@upi.");return}
  try{
    const o=await api("/api/orders",{method:"POST",body:JSON.stringify({productId:state.cart.product.id,quantity:state.cart.quantity})});
    const pay=method==="card"?{method:"card",last4:v}:{method,upiId:v};
    const result=await api(`/api/orders/${o.id}/pay`,{method:"POST",body:JSON.stringify(pay)});
    state.cart=null;$("#cartDrawer").classList.add("hidden");$("#drawerBackdrop").classList.add("hidden");
    toast(result.success?"Payment successful! Order confirmed.":"Payment failed.");
    await refreshAll();go("orders");
  }catch(e){toast(e.message)}
}
async function loadListings(){
  try{
    const ps=await api("/api/my-listings");
    $("#myListings").innerHTML=ps.length?ps.map(p=>`<div class="listing-row">
      <div class="listing-thumb" style="background-image:url('${productImage(p)}')"></div>
      <div class="listing-info"><b>${esc(p.name)}</b><small>${esc(p.category)} · ${p.quantity} ${esc(p.unit||"kg")} · ${esc(p.location||"")}</small><strong>${money(p.price)} / ${esc(p.unit||"unit")}</strong><small>${esc(p.description||"No description added.")}</small></div>
      <div class="listing-actions"><button class="small-btn" onclick="editListing(${p.id},${p.price},${p.quantity})">Edit</button><button class="small-btn danger" onclick="removeListing(${p.id})">Remove</button></div>
    </div>`).join(""):`<div class="empty">You have no products listed yet. Add your first product to start selling.</div>`;
  }catch(e){$("#myListings").innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
async function editListing(id,price,quantity){
  const newPrice=prompt("Enter new price in ₹:",price); if(newPrice===null)return;
  const newQty=prompt("Enter available quantity:",quantity); if(newQty===null)return;
  try{await api(`/api/products/${id}`,{method:"PUT",body:JSON.stringify({price:newPrice,quantity:newQty})});toast("Listing updated.");await Promise.all([loadListings(),loadProducts(),loadDashboard()])}catch(e){toast(e.message)}
}
async function removeListing(id){
  if(!confirm("Remove this product from the marketplace?"))return;
  try{await api(`/api/products/${id}`,{method:"DELETE"});toast("Product removed.");await Promise.all([loadListings(),loadProducts(),loadDashboard()])}catch(e){toast(e.message)}
}
async function createListing(e){
  e.preventDefault();
  const file=$("#listingPhoto").files[0];
  if(file && file.size>1.5*1024*1024){toast("Please choose an image smaller than 1.5 MB.");return}
  const publish=async(photoUrl="")=>{
    try{
      await api("/api/products",{method:"POST",body:JSON.stringify({
        name:$("#listingName").value.trim(),category:$("#listingCategory").value,
        price:$("#listingPrice").value,quantity:$("#listingQuantity").value,
        unit:$("#listingUnit").value,farmName:$("#listingFarmName").value.trim(),
        location:$("#listingLocation").value.trim(),description:$("#listingDescription").value.trim(),
        harvestDate:$("#listingHarvestDate").value,photoUrl
      })});
      e.target.reset();$("#photoPreview").classList.add("hidden");$("#photoPreview").style.backgroundImage="";
      toast("Product published successfully.");await Promise.all([loadListings(),loadProducts(),loadDashboard()]);
    }catch(err){toast(err.message)}
  };
  if(file){const reader=new FileReader();reader.onload=()=>publish(reader.result);reader.readAsDataURL(file)}
  else publish();
}
function statusLabel(status){
  return ({PLACED:"Order placed",PAID:"Payment confirmed",SHIPPED:"Shipped",OUT_FOR_DELIVERY:"Out for delivery",DELIVERED:"Delivered",CANCELLED:"Cancelled"})[status]||status;
}
function deliverySteps(status){
  const steps=["PLACED","PAID","SHIPPED","OUT_FOR_DELIVERY","DELIVERED"];
  const current=steps.indexOf(status);
  return `<div class="delivery-track">${steps.map((st,i)=>`<div class="delivery-step ${i<=current?"done":""} ${st===status?"current":""}">
    <span class="delivery-dot">${i<current?"✓":i===current?"●":"○"}</span><small>${statusLabel(st)}</small>
  </div>`).join("")}</div>`;
}
async function loadSales(){
  if(!["FARMER","SELLER"].includes(state.user.role))return;
  try{
    const sales=await api("/api/sales");
    const paid=sales.filter(x=>x.status==="PAID").length, shipped=sales.filter(x=>x.status==="SHIPPED").length,
      out=sales.filter(x=>x.status==="OUT_FOR_DELIVERY").length, delivered=sales.filter(x=>x.status==="DELIVERED").length;
    $("#salesSummary").innerHTML=[["Total sales",sales.length],["Paid",paid],["Shipped",shipped],["Out for delivery",out],["Delivered",delivered]]
      .map(x=>`<div class="stat"><small>${x[0]}</small><strong>${x[1]}</strong></div>`).join("");
    $("#sales").innerHTML=sales.slice().reverse().map(o=>`<article class="sale-card">
      <div><span class="eyebrow">ORDER #${o.id} · ${esc(o.trackingId||"")}</span><h3>${esc(o.buyer)}</h3>
      <p>${o.items.map(i=>`${i.quantity} ${esc(i.unit||"unit")} × ${esc(i.name)}`).join(", ")}</p>
      <div class="seller-delivery">${deliverySteps(o.status)}</div></div>
      <div class="sale-right"><strong>${money(o.total)}</strong><span class="status">${statusLabel(o.status)}</span>
      ${o.status==="PAID"?`<button class="small-btn" onclick="updateSale(${o.id},'SHIPPED')">Mark shipped</button>`:""}
      ${o.status==="SHIPPED"?`<button class="small-btn" onclick="updateSale(${o.id},'OUT_FOR_DELIVERY')">Out for delivery</button>`:""}
      ${o.status==="OUT_FOR_DELIVERY"?`<button class="small-btn" onclick="updateSale(${o.id},'DELIVERED')">Mark delivered</button>`:""}
      </div></article>`).join("")||`<div class="empty">No customer orders yet. Once buyers purchase your products, their orders will appear here.</div>`;
  }catch(e){$("#sales").innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
async function updateSale(id,status){
  try{
    await api(`/api/sales/${id}/status`,{method:"PUT",body:JSON.stringify({status})});
    toast(`Order #${id} updated to ${statusLabel(status)}.`);
    await Promise.all([loadSales(),loadDashboard()]);
  }catch(e){toast(e.message)}
}
async function loadOrders(){
  const os=await api("/api/orders");
  $("#orders").innerHTML=os.length?os.slice().reverse().map(o=>`<article class="order-card delivery-order">
    <div class="order-top"><div><span class="eyebrow">TRACKING · ${esc(o.trackingId||`AGRI-${String(o.id).padStart(6,"0")}`)}</span><h3>Order #${o.id}</h3>
      <div class="order-meta">${o.items.map(i=>`${i.quantity} × ${esc(i.name)}`).join(", ")}</div>
      <div class="order-meta">${money(o.total)} · Estimated delivery: <b>${esc(o.estimatedDelivery||"—")}</b></div>
    </div><span class="status">${statusLabel(o.status)}</span></div>
    ${deliverySteps(o.status)}
    <div class="delivery-update"><span>Last update</span><b>${esc((o.statusUpdatedAt||"").replace("T"," ").slice(0,16)||"—")}</b></div>
  </article>`).join(""):`<div class="empty">You haven't placed an order yet. Explore the marketplace to get started.</div>`;
}
async function loadAdvisories(){const as=await api("/api/advisories");$("#advisories").innerHTML=as.length?as.slice().reverse().map(a=>`<div class="advisory-card"><span class="soil">${esc(a.crop).toUpperCase()}</span><p>${esc(a.recommendation)}</p></div>`).join(""):`<div class="empty">No advisories yet. Generate your first recommendation.</div>`}
async function loadReports(){try{const r=await api("/api/admin/reports");$("#reports").innerHTML=Object.values(r).map(x=>`<div class="report"><b>${esc(x.title)}</b><pre>${esc(x.content)}</pre></div>`).join("")}catch(e){$("#reports").innerHTML=`<div class="empty">${esc(e.message)}</div>`}}
async function loadUsers(){const us=await api("/api/admin/users");$("#userCount").textContent=us.length;$("#users").innerHTML=us.map(u=>`<div class="user-row"><b>${esc(u.name)}</b><span>${esc(u.email)}</span><span>${u.role}</span></div>`).join("")}
async function generateAdvisory(e){e.preventDefault();try{await api("/api/advisories",{method:"POST",body:JSON.stringify({crop:$("#crop").value,soil:$("#soil").value})});$("#crop").value="";toast("Advisory generated.");await loadAdvisories();loadDashboard()}catch(e){toast(e.message)}}
async function issueAlert(e){e.preventDefault();try{await api("/api/alerts",{method:"POST",body:JSON.stringify({region:$("#alertRegion").value,severity:$("#severity").value,description:$("#alertDescription").value})});$("#alertDescription").value="";toast("Alert broadcast to farmers.");await loadAlerts()}catch(e){toast(e.message)}}
function go(view){$$(".view").forEach(v=>v.classList.add("hidden"));$(`#${view}View`).classList.remove("hidden");$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));$("#pageTitle").textContent={dashboard:"Good day",market:"Marketplace",orders:"My orders",advisory:"Crop advisory",admin:"Admin centre",sell:"Sell products",sales:"My sales"}[view]||"AgriConnect";$("#sidebar")?.classList.remove("open")}
$$(".auth-tabs button").forEach(b=>b.onclick=()=>{$$(".auth-tabs button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#loginForm").classList.toggle("hidden",b.dataset.auth!=="login");$("#registerForm").classList.toggle("hidden",b.dataset.auth!=="register")});
$("#loginForm").onsubmit=async e=>{e.preventDefault();try{state.user=await api("/api/auth/login",{method:"POST",body:JSON.stringify({email:$("#loginEmail").value,password:$("#loginPassword").value})});showApp();await refreshAll()}catch(e){toast(e.message)}};
$("#registerForm").onsubmit=async e=>{e.preventDefault();try{state.user=await api("/api/auth/register",{method:"POST",body:JSON.stringify({name:$("#regName").value,email:$("#regEmail").value,password:$("#regPassword").value,role:$("#regRole").value})});showApp();await refreshAll()}catch(e){toast(e.message)}};
$$(".nav-item").forEach(b=>b.onclick=()=>go(b.dataset.view));$$("[data-go]").forEach(b=>b.onclick=()=>go(b.dataset.go));
$("#search").oninput=renderProducts;$("#category").onchange=async()=>{try{const cat=$("#category").value;state.products=cat?await api("/api/products?category="+encodeURIComponent(cat)):await api("/api/products");renderProducts()}catch(e){toast(e.message)}};
$("#closeCart").onclick=()=>{$("#cartDrawer").classList.add("hidden");$("#drawerBackdrop").classList.add("hidden")};$("#drawerBackdrop").onclick=()=>{$("#cartDrawer").classList.add("hidden");$("#drawerBackdrop").classList.add("hidden")};$("#checkoutBtn").onclick=checkout;
$("#payMethod").onchange=updatePaymentField;
$("#notifBtn").onclick=async()=>{$("#notifDrawer").classList.remove("hidden");await loadNotifications()};$("#closeNotif").onclick=()=>$("#notifDrawer").classList.add("hidden");
$("#logoutBtn").onclick=async()=>{await api("/api/auth/logout",{method:"POST"});state.user=null;showAuth()};$("#mobileMenu").onclick=()=>$(".sidebar").classList.toggle("open");
$("#listingForm").onsubmit=createListing;$("#refreshListings").onclick=loadListings;
$("#listingPhoto").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{$("#photoPreview").style.backgroundImage=`url('${r.result}')`;$("#photoPreview").classList.remove("hidden")};r.readAsDataURL(f)};
$("#advisoryForm").onsubmit=generateAdvisory;$("#alertForm").onsubmit=issueAlert;$("#refreshReports").onclick=loadReports;
boot();
