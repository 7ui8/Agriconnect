# AgriConnect Web Application

This version keeps the existing OOP/business-logic modules and adds a thin browser layer.

## Architecture

Browser (HTML/CSS/JavaScript) → `AgriConnectServer` → existing services/models

The web server uses Java's built-in `com.sun.net.httpserver.HttpServer`, so there is **no new third-party framework or database dependency**.

## Run

Requirements:
- JDK 17+
- Windows, macOS or Linux

From the project root:

```bash
javac -encoding UTF-8 -d out $(find src/main/java -name "*.java")
java -cp out com.agriconnect.web.AgriConnectServer
```

On Windows PowerShell:

```powershell
$files = Get-ChildItem -Recurse src/main/java -Filter *.java
javac -encoding UTF-8 -d out $files.FullName
java -cp out com.agriconnect.web.AgriConnectServer
```

Then open:

`http://localhost:8080`

If port 8080 is busy:

```bash
java -cp out com.agriconnect.web.AgriConnectServer 8081
```

The page and API are served by the same Java process.

## Demo accounts

- Farmer: `john@farm.com` / `pass123`
- Seller: `mary@shop.com` / `pass123`
- Buyer: `alice@buy.com` / `pass123`
- Admin: `admin@agriconnect.com` / `admin123`

## Included web functionality

- Role-based login and registration
- Buyer marketplace, search, category filter, cart and payment
- Seller product listing
- Farmer crop advisory
- Weather alerts and farmer notifications
- Admin user list and reports
- Responsive dashboard
- Loading/error feedback and form validation
- Indian Rupee (`₹`) presentation
- Same-origin HTTP-only session cookie
- Realistic agricultural imagery in the UI

## Important limitation of the supplied backend

The original uploaded project stores users, products, orders and alerts **in memory**. Restarting the server resets the demo/application data. This web layer intentionally does not replace that design with an invented database.

For production deployment, the next backend step would be persistence (for example MySQL) plus password hashing, HTTPS, stronger validation and a proper persistent session/token store.


## Farmer product selling
Farmers can add their own products from **Sell products** and publish them directly to the marketplace.

Each listing can include:
- Product name and category
- Price in ₹
- Quantity and selling unit (kg, quintal, litre, piece, packet, box)
- Farm name and farm location
- Harvest date
- Product description
- Optional product photo (selected from the farmer's computer; under 1.5 MB)

Farmers can edit price, quantity and listing details, remove listings, and see their own sales.

## Farmer sales management
The **My sales** section shows customer orders containing the farmer's products. A farmer can:
- See buyer name, ordered products, quantity and total
- Track PAID / SHIPPED / DELIVERED status
- Mark paid orders as shipped
- Mark shipped orders as delivered
- See total sales counts and revenue on the dashboard

The same selling workflow is available to seller accounts. Buyers can purchase farmer-listed products through the existing cart and payment flow.

### Windows
Double-click `RUN_AGRICONNECT.bat` (or run `.\RUN_AGRICONNECT.bat` from PowerShell). The launcher uses port **8090** to avoid common port-8080 conflicts. Open `http://localhost:8090`.


DELIVERY TRACKING UPDATE
- Buyer order cards now show tracking ID, estimated delivery date, last update time, and a 5-step delivery timeline.
- Farmer/seller sales can progress PAID -> SHIPPED -> OUT_FOR_DELIVERY -> DELIVERED.
- Backend Order now records statusUpdatedAt and exposes createdAt/trackingId/estimatedDelivery.


## Payments
Buyer checkout now supports Card, UPI and Google Pay as selectable methods. The current project uses simulated local payment strategies for demonstration/testing; it does not connect to a real bank, UPI rail or Google Pay merchant account. For production, replace the `process()` methods with a PCI-compliant payment provider such as Razorpay/Stripe and verify webhooks server-side.
